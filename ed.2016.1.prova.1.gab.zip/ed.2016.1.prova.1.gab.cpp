#include <cstddef>
#include <assert.h>

// A questão 1 pede uma classe para o vetor posição:

enum {x, y, z}; // Indices do vetor posição: x = 0, y = 1 e z = 2.

class posicao {
 private:
   double p[3]; // Por coerencia com o resto, coloco aqui um vetor. Poderia ser diferente.
   friend class movimento; // Classe movimento tem acesso aos atributos da classe posicao.
 public:  
   posicao(double px, double py, double pz);
   double getPosicaoX();
   double getPosicaoY();
   double getPosicaoZ();
};

posicao::posicao(double px, double py, double pz) {
  p[x] = px; p[y] = py; p[z] = pz; // Elementos da posição atualizados.
}

double posicao::getPosicaoX() { // Acesso à posição.
  return p[x];
}

double posicao::getPosicaoY() {
  return p[y];
}

double posicao::getPosicaoZ() {
  return p[z];
}

// A questão 2 pede uma classe para a matriz de movimento.
// Esta questão poderia ser entendida como duas matrizes ou seja, duas classe.
// O enunciado sempre trata como matriz de movimento, com diferenças, mas matriz.
// Vamos criar uma única classe. Poderiam ser duas.

enum {T, R}; // Os tipos de movimentos T=0 e R=1



class movimento {
 private:
  double **m; // como a matriz pode ser 3x1 ou 3x3. Será tratada como um ponteiro especifico
  int tipo;        // Em algum lugar será criado uma matriz dinamicamente e atribuído aqui o endereço
  friend class lista;
  
// A questão 3 pede os métodos para o deslocamento (translação) de um objeto.
  
 public:  
   movimento(double **m, int tipo);
   void transladar(posicao &p);
   void rotacionar(posicao &p);
};


movimento::movimento(double **m, int tipo) { // Criando um movimento
  this->tipo = tipo;
  this->m = m;
}

void movimento::transladar(posicao &p) {
  // como esta classe é friend da classe posicao, posso usar suas estruturas internas.
  assert(tipo == T); // somente para garantir que é uma translação.  
  p.p[x] = m[0][x] + p.p[x]; // movimento de translação, estou movimentando o próprio objeto
  p.p[y] = m[0][y] + p.p[y];
  p.p[z] = m[0][z] + p.p[z];
  
  return;
}

// A questão 4 pede uma função para a rotação de um objeto.

void movimento::rotacionar(posicao &p) {
  double temp[3]; // Uma variável temporária é usada pois se trocar o valor de p[x] na primeira
                  // operação este resultado afetaria o cálculo das outras coordenada.
  assert(tipo == R); // somente para garantir que é uma rotação.
  temp[x] = m[x][x]*p.p[x] + m[y][x]*p.p[y] + m[z][x]*p.p[z];
  temp[y] = m[x][y]*p.p[x] + m[y][y]*p.p[y] + m[z][y]*p.p[z];
  temp[z] = m[x][z]*p.p[x] + m[y][z]*p.p[y] + m[z][z]*p.p[z];
  p.p[x] = temp[x]; p.p[y] = temp[y]; p.p[z] = temp[z]; // atualizando a posição.
  
  return;
}

// A questão 5 pede para criar uma lista de movimentos.
// A lista representa uma sequência de movimentos estrita de movimentos.
// Como aplicar os movimentos significa aplicar do primeiro ao último, então
// falamos de uma lista encadeada simples.

class lista {  //A lista contém o movimento e aponta para o próximo elemento.
 private:
  movimento *mv; // Aqui usamos um ponteiro, pois o movimento já existe, apenas inserimos ele na lista.
  lista *prox;
 public:
  lista(movimento *mv);
  
// A questão 6 pede uma função que irá inserir um movimento na lista.
// A preocupação é com o header, então ele (seu endereço) é um parâmetro.
  void inserir(movimento *mv);   
  
// A questão 7 pede uma função que irá aplicar os movimentos em um objeto posição.
// Basta percorrer a lista e transladar quando for translação e rotacionar quando rotação.
  void mover(posicao &p);  
};


lista::lista(movimento *mv) {
  this->mv = mv;
  prox = NULL;
}

void lista::inserir(movimento *mv) {
  lista *l, *nl;
  nl = new lista(mv);
  
  l = this;
  while(l->prox != NULL) l = l->prox; // Vou inserir este movimento após o último.
  l->prox = nl;
  return;
}


void lista::mover(posicao &p) {
  lista *l;
  
  l = this; // Começo do primeiro movimento.
  while(l != NULL) {// tem movimentos a realizar na lista
    if(l->mv->tipo == T) l->mv->transladar(p); // Se o movimento é translacao
    if(l->mv->tipo == R) l->mv->rotacionar(p); // Se o movimento é rotacao
    l = l->prox;
  }
  return;
}
