#include <stdio.h>

#include "ed.2016.1.prova.1.gab.c"

int main(int argc, char **args) {
  // Este programa irá ler matrizes de rotação e translação, criar as estruturas, a lista e aplicar.
  // A entrada contém, na primeira linha 3 valores que representam a posição atual do ponto (x, y, z)
  // Na linha seguinte um número inteiro indicando a quantidade N de matrizes de movimentos.
  // Seguem N conjunto de 4 linhas.
  // Para cada conjunto, a primeira linha contém um caracter 'T' ou 'R' indicando translação ou rotação
  // Se T temos mais tres linhas cada uma com um valor Tx, Ty e Tz
  // Se R temos mais tres linhas cada uma com 3 valores Rxx, Ryx, Rzx na primeira,
  // Rxy, Ryy, Rzy na segunda, e Rxz, Ryz e Rzz na terceira.
  
  int i, n;
  posicao p;
  movimento *m;
  lista *cabeca = NULL;
  double **matriz;
  double dx, dy, dz;
  char tipo;
  
  scanf("%lf %lf %lf\n",&dx,&dy,&dz); // primeiro vamos ler uma posicao.
  p.p[x] = dx; p.p[y] = dy; p.p[z] = dz; // x, y e z estão declarados no arquivo do gabarito.
  
  scanf("%d\n",&n); // Quantos movimentos existem
  
  for(i = 0; i < n; i++) { // Lendo cada um dos movimentos
     scanf("%c\n",&tipo);
     if(tipo=='T') {  // este movimento é de translacao
       scanf("%lf\n",&dx); scanf("%lf\n",&dy); scanf("%lf\n",&dz); // valores a transladar
       matriz = calloc(1,sizeof(double*)); // A matriz de movimento tem dimensão 1x3
       matriz[0]=calloc(3,sizeof(double));
       matriz[0][x]=dx; matriz[0][y]=dy; matriz[0][z]=dz; // Tx Ty Tz
       m = malloc(sizeof(movimento)); // Um novo elemento movimento
       m->tipo = T;  // Atualizando o elemento: tipo
       m->m = matriz; // e matriz
       inserir(&cabeca,m); // Inserindo este movimento à lista de movimentos
     } else if(tipo == 'R') { // este movimento é de rotacao
       matriz = calloc(3,sizeof(double*)); // é uma matriz 3x3
       matriz[x] = calloc(3,sizeof(double)); // Tem de ter espaço para toda a matriz
       matriz[y] = calloc(3,sizeof(double));
       matriz[z] = calloc(3,sizeof(double));
       scanf("%lf %lf %lf\n",&dx,&dy,&dz); // Respeitando a matriz de acordo com a questão
       matriz[x][x] = dx; matriz[y][x] = dy; matriz[z][x] = dz; // Rxx Ryx Rzx
       scanf("%lf %lf %lf\n",&dx,&dy,&dz);
       matriz[x][y] = dx; matriz[y][y] = dy; matriz[z][y] = dz; // Rxy Ryy Rzy
       scanf("%lf %lf %lf\n",&dx,&dy,&dz);
       matriz[x][z] = dx; matriz[y][z] = dy; matriz[z][z] = dz; // Rxz Ryz Rzz
       m = malloc(sizeof(movimento)); // Um novo elemento de movimento
       m->tipo = R; // Atualizando o elemento: tipo
       m->m = matriz; // e matriz
       inserir(&cabeca,m); //Inserindo este movimento à lista de movimentos
     }
  }
  mover(cabeca,&p); // Lista de movimentos está completa, então vamos mover o objeto.
  printf("Nova posicao: %.3lf %.3lf %.3lf\n",p.p[x],p.p[y],p.p[z]); // Nova posição atingida.
  return 0;  
}