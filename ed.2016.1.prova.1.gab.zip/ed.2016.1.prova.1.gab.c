#include <stdlib.h>
#include <assert.h>

// A questão 1 pede uma estrutura para o vetor posição:

enum {x, y, z}; // Indices do vetor posição: x = 0, y = 1 e z = 2.

typedef struct posicao {
   double p[3]; // Por coerencia com o resto, coloco aqui um vetor. Poderia ser diferente.
} posicao;

// A questão 2 pede uma estrutura para a matriz de movimento.
// Esta questão poderia ser entendida como duas matrizes ou seja, duas estruturas.
// O enunciado sempre trata como matriz de movimento, com diferenças, mas matriz.
// Vamos criar uma única estrutura. Poderiam ser duas.

enum {T, R}; // Os tipos de movimentos T=0 e R=1

typedef struct movimento {
  double **m; // como a matriz pode ser 3x1 ou 3x3. Será tratada como um ponteiro especifico
  int tipo;        // Em algum lugar será criado uma matriz dinamicamente e atribuído aqui o endereço
} movimento;

// A questão 3 pede uma função para o deslocamento (translação) de um objeto.

posicao *transladar(movimento *t, posicao *p) {

  assert(t->tipo == T); // somente para garantir que é uma translação.  
  p->p[x] = t->m[0][x] + p->p[x]; // movimento de translação, estou movimentando o próprio objeto
  p->p[y] = t->m[0][y] + p->p[y];
  p->p[z] = t->m[0][z] + p->p[z];
  
  return p; // A função podia ser void. Não precisava retornar p, pois p, ele mesmo, é alterado.
}

// A questão 4 pede uma função para a rotação de um objeto.

posicao *rotacionar(movimento *r, posicao *p) {
  double temp[3]; // Uma variável temporária é usada pois se trocar o valor de p[x] na primeira
                  // operação este resultado afetaria o cálculo das outras coordenada.
  assert(r->tipo == R); // somente para garantir que é uma rotação.
  temp[x] = r->m[x][x]*p->p[x] + r->m[y][x]*p->p[y] + r->m[z][x]*p->p[z];
  temp[y] = r->m[x][y]*p->p[x] + r->m[y][y]*p->p[y] + r->m[z][y]*p->p[z];
  temp[z] = r->m[x][z]*p->p[x] + r->m[y][z]*p->p[y] + r->m[z][z]*p->p[z];
  p->p[x] = temp[x]; p->p[y] = temp[y]; p->p[z] = temp[z]; // atualizando a posição.
  
  return p; // A função podia ser void. Não precisava retornar p. pois p, ele mesmo, é alterado.
}

// A questão 5 pede para criar uma lista de movimentos.
// A lista representa uma sequência de movimentos estrita de movimentos.
// Como aplicar os movimentos significa aplicar do primeiro ao último, então
// falamos de uma lista encadeada simples.

typedef struct lista {  //A lista contém o movimento e aponta para o próximo elemento.
  movimento *mv; // Aqui usamos um ponteiro, pois o movimento já existe, apenas inserimos ele na lista.
  struct lista *prox;
} lista;

// A questão 6 pede uma função que irá inserir um movimento na lista.
// A preocupação é com o header, então ele (seu endereço) é um parâmetro.

lista *inserir(lista **cabeca, movimento *mv) {
  lista *l, *nl;
  nl = malloc(sizeof(lista));
  nl->mv = mv;
  nl->prox = NULL;
  
  if((*cabeca) == NULL) { // pŕimeiro elemento e único
    (*cabeca) = nl;
  } else {
    l = (*cabeca);
    while(l->prox != NULL) l = l->prox; // Vou inserir este movimento após o último.
    l->prox = nl;
  }
  return (*cabeca); //Novamente, poderia ser void. O próprio cabeca foi alterado.
}

// A questão 7 pede uma função que irá aplicar os movimentos em um objeto posição.
// Basta percorrer a lista e transladar quando for translação e rotacionar quando rotação.

posicao *mover(lista *cabeca, posicao *p) {
  lista *l;
  
  l = cabeca; // Começo do primeiro movimento.
  while(l != NULL) {// tem movimentos a realizar na lista
    if(l->mv->tipo == T) transladar(l->mv,p); // Se o movimento é translacao
    if(l->mv->tipo == R) rotacionar(l->mv,p); // Se o movimento é rotacao
    l = l->prox;
  }
  return p; // void nesta também.
}
